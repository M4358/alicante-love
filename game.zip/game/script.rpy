
define s = Character("埃德·萨拉维亚", color="#d9d9d9")
define f = Character("阿莱克斯·费巴斯", color="#7CFC00")
define k = Character("基克·塞蒂恩", color="#87CEFA")
define b = Character("何塞·博尔达拉斯", color="#FFA07A")

default setien_affection = 0
default bordalas_affection = 0
default febas_affection = 0
default victories=0
default failures=0
default chuankong=0
default nofangfan=1
default rustness=0
default k_h=0
default b_h=0
default f_h=0
default endings_unlocked = []
default match_c1=0
default k_meet=0
default b_meet=0
default f_meet=0
default meet=0

screen brightness_overlay():

    add Solid("#000") alpha 0.03*rustness

image bg_santander=Transform("images/santander.png",zoom=1.2)
image bg_training=Transform("images/training.png",zoom=1.2)
image bg_getafe=Transform("images/getafecf.png",zoom=1.2)
image bg_elche_scene=Transform("images/elche_scene.png",zoom=1.2)
image bg_elche_night=Transform("images/elche-night.png",zoom=1.2)
image bg_setien_inner=Transform("images/setien_inner.png",zoom=1.3)
image bg_setien_outside=Transform("images/setien_outside.png",zoom=1.3)
image bg_alicante_scene=Transform("images/alicante_scene.png",zoom=1.2)
image bg_alicante_hotel=Transform("images/alicante_hotel.png",zoom=1.3)
image black=Transform("images/black.png",zoom=1.5)
image bordalas = Transform(
    "images/bordalas.png",
    zoom=0.7
)
image setien = Transform(
    "images/setien.png",
    zoom=0.7
)
image febas = Transform(
    "images/febas.png",
    zoom=0.7
)
image sarabia = Transform(
    "images/sarabia.png",
    zoom=0.7,
    size=(1210,1536)
)
label start:

    scene bg_elche_scene

    "《阿利坎特之恋》————序章"

    show sarabia:
        xalign 0.5
        yalign 1.0

    "这是我来到埃尔切，这座阿利坎特海边的古典小城市的第二年。阿利坎特的夏天，晴空万里，空气浓稠而炙热，所有的东西都开始狂热，都开始升腾。"

    "我刚刚带领埃尔切足球俱乐部重返西甲。球员们把我抛起来，高喊着萨拉维亚教练的名字。球迷们夹道欢迎，彻夜欢歌。"

    s "(欢呼) 该死的，我们赢了！我们回西甲了！"

    "但是，阿利坎特的夏天可是很热的。有什么燃烧起来了，我的预感告诉我，这个夏天会发生狂热的、炽烈的、熔化一切的事情。我不知道是好是坏，也不知道接下来的时光里，我会永远得到或失去什么。"
    hide sarabia
    show febas:
        xalign 0.8
        yalign 1.0

    f "（对采访）感谢萨拉维亚教练一年来对我毫无保留的信任，我一直将他当作我的家人一般看待。"
    hide febas
    show setien:
        xalign 0.8
        yalign 1.0
    k  "埃德，我一直都最看好你、最信任你。现在你成功了，你踢出了如此出色的传控，而且取得了如此耀眼的成绩。我为你骄傲。"
    hide setien
    show bordalas:
        xalign 0.8
        yalign 1.0
    b  "没想到你小子居然带队升级了，小萨拉维亚。可西甲的舞台，还是papa我的实用主义足球的天地~"
    hide bordalas

menu:

    "去混采区表扬阿莱克斯一番":
        $ febas_affection += 1
        jump febas_scene1

    "回复博尔达拉斯的挑衅短信":
        $ bordalas_affection += 1
        jump bordalas_scene1
    
    "和恩师共同庆贺升级":
        $ setien_affection += 1
        jump setien_scene1

label setien_scene1:

    scene bg_santander


    
    "那个人的教诲一直指引着我。那个从小呵护着我的人，替我在巴萨挡住媒体的长枪短炮的人，那个从父亲还在桑坦德竞技效力的时候我就追随的人。"
    "球队一升级，我就给老师发了邮件，要知道我足球的理念全部源自于他，我的战术也全部是在跟随他的六年中学来，在后来独立执教的时光里，一次又一次实践。所以，这份荣誉，也是属于他的，我在埃尔切第一年的成功，第一个要分享的，也是他。"
    show sarabia:
        xalign 0.5
        yalign 1.0
    s "塞蒂恩先生！你回西班牙了。"
    hide sarabia
    show setien:
        xalign 0.8
        yalign 1.0
    k "好样的，埃德。你的每场比赛我都看了，细节上有一些瑕疵，但整体做得非常漂亮。传控足球的精髓就在于每个人都像一枚棋子一样精密。"

    k "我买了坎塔布里亚海的鲑鱼和安达卢西亚的赫雷斯酒。今晚是属于你的，好好吃些东西，新赛季继续努力。"
    hide setien
    show sarabia:
        xalign 0.5
        yalign 1.0
    "我和塞蒂恩先生已经共事六年了。在坎塔布里亚，他见证着我成长，在安达卢西亚，我们并肩作战，他设计出精密的战术，我把它们传达给球员。还有巴塞罗那和拉斯帕尔马斯。"
    "那么多年里，他总是一板一眼，从来没有像今天这样笑过，笑得脸上的皱纹都完全舒展开了，即使在他自己生涯的巅峰也没有。他是真心为我的成就而骄傲的。"

    s "塞蒂恩先生，您还是多笑笑嘛。"
    hide sarabia
    show setien:
        xalign 0.8
        yalign 1.0

    k "你执教安道尔踢出来的战术，没把我气死都不错了。现在好多了。你得继续加油，别让我失望啊，埃德。"

    "为了不让塞蒂恩先生失望，我会好好努力的。"

    jump chapter1_1stmatch

label bordalas_scene1:

    scene bg_getafe

    "何塞·博尔达拉斯，我恩师的死敌，那位长相像街痞，被赫塔菲的拥趸们尊为papa的阿利坎特主教练。"
    "他把足球踢成了一场街头斗殴，极度务实，也极度破碎与凌乱，整天就在构思一些研究裁判、犯规和盘外招之类的东西，把恩师和我气的七窍生烟，天天在媒体上指桑骂槐。而且他说话真让人恶心。"

    show sarabia:
        xalign 0.5
        yalign 1.0    

    s "你*个**的踢**足球的玩意，又玩盘外招。你那一套我可没少研究，等我去了西甲，我会把球稳稳当当地传进你的球门。"
    hide sarabia
    show bordalas:
        xalign 0.8
        yalign 1.0

    b "你又不是不知道，你恩师在papa我手下可从没尝到什么甜头。既然你这么有自信，要不要打个赌？"
    hide bordalas
    show sarabia:
        xalign 0.5 
        yalign 1.0
    s "赌就赌，你**不会是觉得我没胆量吧。我会赢你三个。"
    hide sarabia
    show bordalas:
        xalign 0.8
        yalign 1.0

    b "好啊，输了可不许骂裁判。你要是输了，就带着阿利坎特上好的特产来聆听我的伟大教诲吧。"
    hide sarabia
    show bordalas:
        xalign 0.8
        yalign 1.0
    s "（能不能别这么自恋……）"


    jump chapter1_1stmatch

label febas_scene1:

    scene bg_elche_night
    "阿莱克斯·费巴斯，我队伍里最有灵性的球员，也是我最信任的战术核心。他总是能够精确找到对手阵型的空当，一丝不苟地跑出那些复杂的球路，而且训练还十分努力。"
    "而且，他对我和我的传控哲学深信不疑。"
    show febas:
        xalign 0.8
        yalign 1.0

    f "教练，你怎么来了。"
    "阿莱克斯从后面揽住我，我们一起站在采访区。我们之间的关系是不是显得太过于好了？但考虑到他是一个如此严肃认真的球员……"
    hide febas
    show sarabia:
        xalign 0.8
        yalign 1.0

    s "阿莱克斯是这支埃尔切当之无愧的战术核心。我感激能遇到这么好的球员，也感谢他不遗余力、倾尽所有，把自己的全部才华和努力奉献给了这支埃尔切，才会有今天的升级。"
    hide sarabia
    "聚光灯下，阿莱克斯似乎腼腆地笑了。"
    jump chapter1_1stmatch

label chapter1_1stmatch:
    "《阿利坎特之恋》————第一章"
    scene bg_elche_night

    show sarabia:
        xalign 0.5
        yalign 1.0
    "西甲联赛开始了。我期待新的挑战，也感受到压力。埃尔切的总监支持我，为我买来了很多球员，种种期待落在我身上。"
    "我想让阿莱克斯发挥更大的光芒，也想把我在西乙时期贯彻的塞蒂恩主义和细腻传控发扬光大，还得狠狠挫一挫博尔达拉斯这家伙的锐气。"

    "不过作为一个西甲教练，压力也很大……西甲的赛场比西乙更为残酷。接下来一段时间的赛程，踢什么战术呢？"
menu:

    "传控":
        $ setien_affection+=1
        $ chuankong += 1
        $ victories += 1
        jump victoryc1

    "防反":
        $ bordalas_affection += 1
        $ nofangfan =0
        $ chuankong-=1
        $ rustness +=1
        $ failures +=1
        jump defeatc1
    
    "征求一下阿莱克斯的意见？":
        $ febas_affection += 1
        $ chuankong +=1
        $ victories+=1
        jump aleix_instruction

label aleix_instruction:
    scene bg_elche_night
    show febas:
        xalign 0.8
        yalign 1.0
    f "教，教练？您问我踢得顺不顺利？"
    f "就踢我们原来在西乙踢的那套吧，请信任我，我一定会为您串联起美妙的进攻的。"
    s "（不用问也知道……）"
    jump victoryc1


label victoryc1:
    show screen brightness_overlay
    show bg_elche_night
    "用着从西乙时期就坚持的精细传控战术，我们在这一段时间不仅所向披靡，还能取得很多大胜。笑容洋溢在更衣室每个人的脸上。"
    "那个总是和我一起研究战术到深夜的人……有在看吗？"
    "阿莱克斯完成得非常好。他还有什么我不知道的惊喜才能？"
    jump chapter1_meet

label defeatc1:
    show screen brightness_overlay
    show bg_elche_night
    "我试图转向务实打法，可是不得要领。我们没有一技之长，毫无抵抗之力地溃败。"
    "阿莱克斯有点失望，这样下去，不是办法。"
    "一到西甲就背叛了塞蒂恩先生的战术，我也变得太怯懦了，我都不敢想他会怎么说我。难道我们共同追求的伊甸园，是那么地无谓？"
    "我是不是被博尔达拉斯那家伙影响太深了？"
    "【你感到失去了一部分的自我。请注意，如果失去太多的自我，将会走向不可逆转的毁灭。】"
    jump chapter1_meet

label chapter1_meet:
    show screen brightness_overlay
    scene bg_elche_scene
    "赛程中间的小小间歇，要去见一见谁吗？"
    $ meet+=1
    if meet==3:
        jump chapter1_ending
menu:
    "塞蒂恩先生":
        $ setien_affection+=1
        $ k_meet+=1
        if k_meet==1:
            jump setien_1stmeet
        if k_meet==2:
            jump setien_2ndmeet
        if k_meet==3:
            jump setien_3rdmeet
    "何塞·狗尔达拉斯":
        $ bordalas_affection +=1
        $ b_meet+=1
        if b_meet==1:
            jump bordalas_1stmeet
        if b_meet==2:
            jump bordalas_2ndmeet
        if b_meet==3:
            jump bordalas_3rdmeet
    "阿莱克斯":
        $ febas_affection +=1
        $ f_meet+=1
        if f_meet==1:
            jump febas_1stmeet
        if f_meet==2:
            jump febas_2ndmeet
        if f_meet==3:
            jump febas_3rdmeet

label setien_1stmeet:
    show screen brightness_overlay
    scene bg_setien_outside
    show sarabia:
        xalign 0.2
        yalign 1.0
    "赛程的小小间歇，我来到了塞蒂恩先生在桑坦德的住所，坎塔布里亚海边的小屋。远渡重洋执教不顺，赋闲之后，塞蒂恩先生一直住在这里。"
    "独立执教六年，期间发生了那么多的事情，这里对我来说是港湾一样的地方……或者洋溢着更复杂情绪的地方。"
    "我敲了门。"
    
    if chuankong<=0:
        hide sarabia
        show setien:
            xalign 0.8
            yalign 1.0
        k "恕不接待。我倾囊相授，埃德，不是为了有一天拿你踢出来那套丑陋足球打我的脸！"
        "再怎么求情，塞蒂恩先生都不放我进去。"
        jump chapter1_2ndmatch
    if chuankong>0:
        $ setien_affection+=1
        scene bg_setien_inner
        show setien:
            xalign 0.8
            yalign 1.0
        k "埃德，你来了。你是不是又在更衣室发脾气了？眉头的皱纹都多了。你的比赛，我每场都看。"
        s "有、有达到先生的严格要求吗？"
        "不知怎么地，我一和塞蒂恩先生说话就有点结巴。他还是那副不苟言笑的样子。"
        k "比起上赛季有长进吧。埃德，你还是该稳重点，你这样太容易被媒体做文章了。"
        "似乎还是没有得到全然的认可，有点挫败。后半句的说教，我权当耳旁风了，塞蒂恩先生不明白，我做他身边那个张扬的战术推行者，总好过让他承担一切压力。"
        "塞蒂恩先生做了简单的餐食，我们坐在小屋的桌边，吹着坎塔布里亚的海风，仿佛回到了从前。父亲和他在踢球的时候相识，我从8岁就一直仰望着他，后来他提拔我，我跟着他走南闯北。"
        "我注意到电视柜角的劳拉西泮，似乎从出海执教失败以来，塞蒂恩先生的精神状态就有些令人担忧……"
        s "好吃！（挤眉弄眼）"
        k "别一副那么谄媚的样子。"
        hide sarabia
        hide setien

        "晚饭后，我们探讨起战术。塞蒂恩先生坐在我身后，认真地在笔记本上圈圈画画，有时赞赏我的战术设计，有时会强行纠正我。"
        show setien:
            xalign 0.8
            yalign 1.0
        k "埃德，我年纪大了。我所有的东西，都传给你了，我和我们的梦想，也只有你了……"
        "他的手覆在我的手上，似乎除了传道授业之外，意有所指。我不敢相信地对上塞蒂恩先生的眼睛，那双眼睛闪烁着一些……危险的秘氛。"
        hide setien
        menu:
            "顺势倒进塞蒂恩的怀里":
                "这个人似乎前所未有地脆弱，渴求着我的依赖。我又怎么能不回应？"
                $ setien_affection +=1
                $ rustness +=1
                k "埃德……以后多来看看我。"
                s "……好。"
                "【你感到失去了一部分的自我。请注意，如果失去太多的自我，将会走向不可逆转的毁灭。】"
            "握住塞蒂恩的手":
                "塞蒂恩先生……压力太大了。"
                $ setien_affection +=1
                s "您就放一万个心吧，我会好好把学到的东西用在带教上的。"
            "慌不择路地逃离":
                $ setien_affection -=1
                k "(捶桌子）为什么！连埃德也逃走了？"
        jump chapter1_2ndmatch

label bordalas_1stmeet:
    show screen brightness_overlay
    scene bg_alicante_scene
    show sarabia:
        xalign 0.5
        yalign 1.0
    "那个老和我在媒体上打口水仗的轻佻老男人，好像回了老家阿利坎特。他问我要不要喝一杯，我起初没理他。"
    "然后我就在难以言喻的冲动之下驱车一小时，出现在这里了。"
    if chuankong>0:
        hide sarabia
        show bordalas:
            xalign 0.8
            yalign 1.0
        b "抱歉啦，我的日程还是挺忙的呢~塞蒂恩身后那个亦步亦趋的小子啊，何必非要见我不可呢？"
        jump chapter1_2ndmatch
    if chuankong<=0:
        hide sarabia
        show sarabia:
            xalign 0.2
            yalign 1.0
        "我不知道为什么开车过来，也不知道为什么最后就在这里了。我坐在博尔达拉斯的对面，用吸管搅着威士忌里的冰块……"
        show bordalas:
            xalign 0.8
            yalign 1.0
        b "啧啧啧。要不我把和你见面的照片发到推特上，让塞蒂恩那家伙暴跳如雷？"
        b "不过我听说你在禁区前面蹲坑防守，让人踢了个3-0。你来我这，总不能是投诚吧？赫塔菲缺个助教，你要不先跟着我学一年？"
        s "停停停，你邀请我，我才来的，又不是谁闲的**非要来你这里。"
        b "那你也知道我为什么邀请你吧？刚出道就背叛师门的小子？我在你这，看到了些许潜力，你会成为大放异彩的战术天才，但首先你要成为你自己。"
        "其实相谈还算是开心，博尔达拉斯是一个轻佻之下意外热心的人，只是我不太愿意承认。塞蒂恩先生总是太端着，跟着他，总觉得自己年纪轻轻就没有了活力。"
        "赌上我毕尔巴鄂人的尊严，我要把他喝翻。酒过三巡之后，我后悔了。"
        "这个62岁的阿利坎特男人怎么这么能喝！"
        hide sarabia
        b "跟着塞蒂恩那么久，你怎么可能懂防守。"
        b "……也怎么可能懂，阿利坎特人的，{b}生活方式{/b}。"
        "迷糊之中，他向我伸出了手。尽管我神智还算是清明，但是那一句话，我怀疑我会错意了。"
        menu:
            "跟着他走":
                $bordalas_affection +=2
                $rustness +=1
                jump bordalas_h1
            "时候不早了，离开吧":
                $bordalas_affection+=1
                jump chapter1_2ndmatch
label bordalas_h1:
    show screen brightness_overlay  
    scene bg_alicante_hotel
    $ b_h+=1
    "我，埃德·萨拉维亚，一位一生要强的毕尔巴鄂男人。我不知道为什么就跟着他走了，就像被塞壬歌声蛊惑的船员一般。"
    "他去隔壁酒店开了个房间，说是得把这个喝的有点神志不清的男人安顿好。我知道我没有神志不清，他也不是为了安顿好我。"
    "在那里，发生了无法言喻的事情。在此之前，我觉得我对塞蒂恩先生和他的战术理念忠心耿耿。但是从决定驱车前来的那一刻，到现在，我并不想踩下刹车。"
    "原谅我……这哪里是一场，像样的反叛。"
    show sarabia:
        xalign 0.8
        yalign 1.0
    s "博尔达拉斯，你哪来的胆子？"
    hide sarabia
    show bordalas:
        xalign 0.8
        yalign 1.0
    b "你哪来的胆子跟着我上车，小萨拉维亚？"
    hide bordalas   
    "“小萨拉维亚”其实应该是对我的官方称呼，因为我的父亲马努·萨拉维亚是他的同辈。但事到如今，这个称呼早就生了什么调情的意味。"
    "我汗湿的肌肤和他紧实有力的胸膛贴在一起。他哪来的胆子吻我？我又是哪来的胆子，磕磕绊绊咒骂着回应？"
    s "难道你是一个，为了招揽死敌的徒弟，连肉体关系都来者不拒的人？"
    b "你自己的脚让你走了上来。你自己的欲望让你沉迷于此，小萨拉维亚。你得正视它们，你该学会享受。我打赌，塞蒂恩这个老顽固一辈子没享受过这些。"
    "对他而言，这只是阿利坎特的一场普通迷情？我的脑子已经被搅得乱七八糟了。但不得不承认，他在这里的技巧，比他的球员在场上犯规的技巧还要丰富……"
    "那是一场单方面的溃败。我在他的身下失控得不成样子，几乎交出了全部的自我；但我并不想停下。"
    scene black
    "……"
    scene bg_alicante_scene
    "天亮了。"
    "博尔达拉斯，消失了。"
    "我从未觉得如此失控过。"
    "【你感到失去了一部分的自我。请注意，如果失去太多的自我，将会走向不可逆转的毁灭。】"
    jump chapter1_2ndmatch
label febas_1stmeet:
    show screen brightness_overlay
    scene bg_elche_scene
    "去见他吧。敏感的阿莱克斯最近训练格外刻苦，我想让他知道他的努力有被看见。尽管在我驱车去他家的路上，隐秘的不安感席卷着我。我很了解他，最近他的眼睛看向我的次数变多了。"
    "他的职业生涯很不顺利，明明有着不俗的水平，却大器晚成，随队回到西甲时已经30岁了。从马拉加降级之后，他就一直蹉跎西乙，我们不可谓不是彼此命运中的转折人物，因此关系很特殊。"
    "但是……他需要一些正确的引导，我本不该频繁和他接触。这样下去，我是否，也在纵容他？或是……纵容自己？塞蒂恩先生说过，过度的纵容会毁了我。"
    show febas:
        xalign 0.8
        yalign 1.0
    f "教练，家访之前说一声嘛。"
    show sarabia:
        xalign 0.2
        yalign 1.0
    "他坐进了我的副驾。看到我过来，平时腼腆的他笑得格外开心。"
    f "我最近有在加练。虽然大家都习惯了被您在更衣室训，但最近您好像训得更多了，所以我也在想，是不是自己有点太过松懈了什么的。"
    s "加练？你还是太把我的态度当回事了，我就那性格。我就是担心你会错了意，然后逼自己太紧，所以来特意点拨你。实际上，这几场，你……踢得太好了，超出我能想到的好。"
    f "呵呵呵……恐怕您是因为从来没在塞蒂恩先生那里听到这句话，才迫不及待地对我说的吧？请别这样，我会高兴过头的。"
    s "哪有。总之，自信些不是坏事。"
    "塞蒂恩先生。跟他说话时，我嘴里总是会不知为何吐出一些对塞蒂恩先生的抱怨。我仰望和追随着塞蒂恩先生；然后现在有一个年轻干净的灵魂，开始隐隐约约以同样的方式仰望和追随着我。"
    "真正站在这个角色上的时候很沉重。但是这也让我想成为更好的人。"
    f "教练，这么久了……我有一个秘密要告诉你。"
    f "……还是算了。下次见面的时候再说吧。"
    "他的眼神，出卖了一切。"
menu:
    "以年长者的经验，直接吻他":
        $ febas_affection +=1
        $ rustness +=1
        "按说作为年长者应该更加主动；我在这些情感还是混沌的时候听信了自己的本能，把他拉进怀里，然后吻到他嘴唇红肿才放开。"
        "阿莱克斯不敢置信，脸颊红扑扑的，却也不肯和我分开。而本该引导的我，直接拉着他的手，往自毁的禁忌深渊里跳。"
        "【你感到失去了一部分的自我。请注意，如果失去太多的自我，将会走向不可逆转的毁灭。】"
        jump chapter1_2ndmatch
    "秘密需要时间沉淀，那就下次再说":
        $ febas_affection +=1
        f "谢谢你。"
        f "我会……深思熟虑的。"
        jump chapter1_2ndmatch
    "别再走上歧途了，作为年长者敲打他":
        $febas_affection -=1
        s "如果是我想的那样的话，就先别说吧，别再给自己暗示。好好想想你的未来，你后面的职业生涯，如果误入歧途我们只会彼此耽误。"
        f "您退缩了么……可我不是缺乏理性的人。"
        jump chapter1_2ndmatch
label chapter1_2ndmatch:
    show screen brightness_overlay
    scene bg_elche_night
    "休赛期过的很快，西甲联赛又开始了。这段时间，踢什么战术好呢？"
menu:
    "还是传控":
        $ setien_affection+=1
        $ febas_affection+=1
        $ chuankong += 1
        $ victories += 1
        jump victoryc1
    "改踢防反吧":
        $ bordalas_affection += 1
        $ nofangfan =0
        $ chuankong-=1
        $ rustness +=1
        $ failures +=1
        jump defeatc1
label setien_2ndmeet:
    show screen brightness_overlay
    scene bg_setien_outside
    show sarabia:
        xalign 0.5
        yalign 1.0
    "我又来到了我的港湾，坎塔布里亚的小屋，塞蒂恩先生的住所。上次之后，我们经常联系。赋闲独居的他脾气变得更古怪了，不是重要的客人一概不见，我有些担心他，也思念他。"
    if nofangfan==0:
        "门扉紧闭。塞蒂恩先生从上周起就不回我的短信和电话，我站在门外，听到了低低的咒骂声和玻璃碎裂的声音。"
        "我知道，他是眼里揉不得沙子的人。"
        "我没有告诉他我来过，离开了桑坦德。"
    else:
        hide sarabia
        show setien:
            xalign 0.8
            yalign 1.0
        "我远远就见到了在门口张望的塞蒂恩先生。他憔悴了很多，但对上视线的那一刻，他黯淡的面容几乎是瞬间恢复了气色。他给了我一个大大的拥抱，我简直快要哭出来了。"
        show sarabia:
            xalign 0.2
            yalign 1.0
        s "好了好了……我可是每时每刻都在惦记着您的呀，塞蒂恩先生。"
        k "你来看我，几乎是这段时间里唯一值得高兴的事情了。日程很满吧？媒体都把你夸成战术大师了，说你在西甲踢最华丽的传控足球。"
        s "都是塞蒂恩先生教导有方嘛。"
        k "油嘴滑舌。"
        scene bg_setien_inner
        hide sarabia
        hide setien
        "屋子里的陈设还是一样整齐，电视上播放的是埃尔切的比赛画面，桌上摊开着厚厚一沓战术笔记。赋闲之后，他看我的每一场比赛，为它们写战术分析，不少的精力用在了我身上。"
        "桌子上的物品被照进来的阳光分成了两个部分；阳面是那叠战术笔记，阴面是酒精和精神类药物。短信里，他只告诉我“有点失眠”。"
        "那是一个很有隐喻性的画面：我在光明里，他在阴影中。我在西甲最成功的几个月，塞蒂恩先生反倒变得更颓废了。他不会承认这些，但无端的愧疚笼罩了我。"
        "可我应该说什么？"
        s "我可以看吗？您写的笔记。在您这里学了这么久，总得跟您对对标准答案。"
        k "那算什么标准答案。我只知道怎么设计短传线路，可是不知道怎么赢。你知道怎么赢。"
        s "塞蒂恩先生……"
        "塞蒂恩先生聊起了他的近况。"
        show setien:
            xalign 0.8
            yalign 1.0
        k "我很长时间都没走出这扇门了，也没接到什么人的电话。……整天失眠，唯一的娱乐就是写书和看足球。经常是西甲，我也看埃尔切，看你在场边骂那些球员，看你的发布会。"
        show sarabia:
            xalign 0.2
            yalign 1.0
        s "那我做得够好吗，塞蒂恩先生？"
        k "……很好。不对，是太好了。即使是你跟着我，我们在西甲执教的时候，我们都从来没有赢过那么多球。"
        s "那是我们共同抵达的地方，不是吗？因为有您在。"
        k "听我说，埃德。你做得太好了，你自己已经走出了这么远的路，赢了这么多球。恐怕你下次来，我就没什么能教给你的了。"
        "他紧紧攥着我的手，攥得骨节发白。他不会承认他表露出来的那些脆弱和恐惧，但我听懂了：我成功了，走远了，把他抛弃在这里，他该怎么办。"
        "跟着他漂泊多年，我是那么了解他。而我又是多么渴望，打破和他之间那层恩师和爱徒的界限。而现在，他绝不可能逃避。"
    menu:
        "“不管我在哪里，踢得有多成功，我都已经是您的了”":
            $setien_affection +=2
            $rustness +=1
            "【你感到失去了一部分的自我。请注意，如果失去太多的自我，将会走向不可逆转的毁灭。】"        
            if rustness<1:
                k "你没必要把所有价值绑定在我身上。做你自己的事，偶尔来看看我就好。"
                jump chapter1_2ndmatch
            else:
                k "你确实悟性很好。埃德，来我房间。"
                $k_h+=1
                jump setienh1_1
        "“要不要，这次我来教您？教您，做我的人？”":
            if setien_affection<3:
                k "你是不是喝多了？对待长辈要保持尊重。"
            else:
                "塞蒂恩先生不发一词。他的眼睛亮得灼人。"
                "我精准地找到了他的嘴唇，吻了上去。"
                $k_h+=1
                jump setienh1_2
        "“别担心啦，我多来看看您不就好了。”但不做进一步的表示":
            $setien_affection +=1
            k "我知道的，我能克制。"
            jump chapter1_2ndmatch

label setienh1_1:
    show screen brightness_overlay
    scene black
    "塞蒂恩先生的卧室没有开灯。唯一的光源是窗帘缝隙透进来的丝丝缕缕，和床头点燃的几支蜡烛，它们散发出的异样薰香飘荡在房间里。"
    "我突然觉得，这其实是一场设计好的献祭。塞蒂恩先生是脑内推演的大师，他计算球员的跑位、计算棋子的位置、计算一切。所以他不可能不懂心理。"
    "他也并不仅仅是一个，被理想与现实的错位折磨得精神不振的坎塔布里亚老人。他是一个设计师，战场上的艺术家，所以他设计了这有着哥特美学的献祭现场。他在用自己唯一知道的方式确认自己的存在。"
    "而我是自愿走进祭坛中心的人。我洗干净自己，面对着蜡烛，然后等着塞蒂恩先生在我身上描摹欲望。"
    show setien:
        xalign 0.8
        yalign 1.0
    k "我没看错你，埃德。你就是我创造的最美妙的艺术品，我的另一段生命，也是我唯一的慰藉。"
    k "你的呼吸乱了，埃德。要冷静，要耐心地控制好场面，等到对手出现破绽，再一举进攻。"
    hide setien
    "塞蒂恩先生声音低沉而狂热，好像变成了另一个人，我平时听惯了的战术指导也变成了另一套暧昧的语词。我想要看到他的另一面，他就完全暴露给了我。"
    "塞蒂恩先生并不是不会调情，或者床笫间的技巧。只是他在做这些的时候，有一种和他的战术一样的冷酷无情的色彩。"
    k "让你的球员占据每一个位置。然后，让阵型流动起来。怎么了埃德，到极限了吗？"
    "蜡油在我的胸前与腹部汇流成战术图，每个球员的位置、每条传跑的路线。足球术语与最原始的喘息融在一起，变成了独属于我们之间的第三种艺术。"
    "而我在塞蒂恩先生身下抖如筛糠，却连呼吸的频率都极力克制着不敢加快。可他还是那么冷静，那么精密。"
    "在这克制与放纵的撕裂之中，我最终失去了意识。"
    k "做得很好，埃德。你是我的。"
    jump chapter1_2ndmatch

label setienh1_2:
    show screen brightness_overlay
    scene bg_setien_inner
    "塞蒂恩先生惊愕了一秒，随即比谁都快地接受了这件事的发生。我们之间的界限，从来都有些……摇摇欲坠。"
    "不同于阿利坎特天气晴好，坎塔布里亚下雨了。暴烈的雨打在窗户上，木制窗户被风吹得咯吱作响。天气晴好的是阿利坎特。下雨的是坎塔布里亚。"
    show sarabia:
        xalign 0.2
        yalign 1.0
    s "塞蒂恩先生……不，基克。我知道……事情不仅仅是那样。我知道您是一个重视位置的人，现在您觉得自己没有位置了。"
    s "我等这一天等了很久。我会告诉您一些位置之外的东西。我知道……我带着您的期望，现在队伍踢得很好，您不是不想我好，是怕我离开。"
    s "我不会离开的。现在交给我吧。你知道，我有很多办法让球员相信我的话，不是一句干巴巴的承诺。"
    hide sarabia
    scene black
    "塞蒂恩先生陷入了更长的沉思，随后低语了几句听不清楚的话。他颤抖着，却只是更紧地依偎着我。我把他抱到卧室，第一次发现他的身体瘦得像是只剩骨架。但这副骨架里还是那副在场边一丝不苟、指挥若定的塞蒂恩先生，从来没有变过。"
    "然后我急切地把他抵在床头柜上吻他，等待他仔细地攀上我的身体、确认我的存在，然后找回些许神智。"
    k "埃德，你跟着我学战术，就为了有一天这么对待我？还是等我被世界遗忘的时候来拯救我？"
    s "我爱您不仅仅是因为那些战术。我在等您认可我，等您主动关心我，就像现在等您说出您也需要我、想要我。然后我发现我已经知道答案了。"
    s "我认识您六年。我知道什么可以做，我知道到了什么地步您才不会压抑自己的感情。告诉我，你想要我，基克。这不意味着你输了。"
    k "……埃德。你知道我是个苛刻的人。我会后悔。"
    s "如果我现在离开，您就不会后悔吗？"
    k "……也许你是对的，埃德。我……想要你。"
    "那句话像是打开了闸门。我本来就不是什么冷静的性格，我平均每天要在场边骂三次球员。而面对塞蒂恩先生，我需要冷静忍耐，拆解那么多层防线才能得到他的青睐。"
    "一点小的奖励是应有之义。而且我很快发现了在这里我无论怎么打破秩序，都不会招致他真正的怒火。所以我愈发放纵了，我用手掌抚摸过他身体的每一处轮廓，甚至撩拨那些敏感的部位。"
    "慌乱的塞蒂恩先生很想做回那个严肃的导师形象，他用力攀着我的手、咬住下唇不让自己发出声音，或是厉声叫我的名字。但我有意让狂乱掌控一切。"
    "我像是第一天重新认识了塞蒂恩先生，他恐怕也是重新认识了我。如果一切早点发生就好了。"
    scene bg_setien_inner
    "天亮了。"
    show sarabia:
        xalign 0.2
        yalign 1.0
    show setien:
        xalign 0.8
        yalign 1.0
    k "埃德，我觉得你应该给我一个解释。"
    s "您精神状态不是好多了？这就是解释。有的时候还是应该相信自己的本能。"
    jump chapter1_2ndmatch

label bordalas_2ndmeet:
    show screen brightness_overlay
    scene bg_alicante_scene
    "上一次是在阿利坎特，这一次是在马德里。埃尔切赴客作战，几天前发来的短信却一直牵动着我的心绪。"
    "“有潜力的小萨拉维亚，欢迎来我这边喝两杯~”"
    if nofangfan==1:
        "我回复了短信，石沉大海。他或许是忙吧。然后过了几天，收到了回复。"
        "“你还在踢塞蒂恩那套无菌足球啊？先让你飘飘然几天，省得跑过来嘲讽我。”"
        "呵，博尔达拉斯也不打逆风局吗？"
    else:
        show bordalas:
            xalign 0.8
            yalign 1.0
        show sarabia:
            xalign 0.2
            yalign 1.0
        "和酒量惊人的阿利坎特人碰面了。这次绝不能再和他对着喝了。"
        b "频繁来见我，是想在战术板上和行为上都挑战一下塞蒂恩那家伙的权威？这不是小孩子才会干的事吗？毕竟，塞蒂恩那家伙见我一面都觉得是脏了他的眼睛。"
        s "……我**一定要按照那样来吗？不是你，就是塞蒂恩？就不能单纯找你吹吹水？"
        b "那说明你至少和塞蒂恩不一样，你觉得我还有点意思。"
        s "确实。至少不是只有足球。也不需要面对那些借口。……但并不代表犯规和盘外招，就是我认同的足球了。"
        b "我也只是想活下去，留在西甲。如果你问我建议，我也只会建议你先活下去。用你的一切才能，不只是传控。你比我幸运，你42岁，我60岁才摸到顶级联赛舞台。在你到达极限，无论如何都想要前进的时候，你会想办法的。"
        s "……我知道。"
        b "多探索吧。虽说我们还称不上同道中人，但你还挺有意思的，小萨拉维亚。我还是希望你能去更大的舞台，而不是像你老师一样丢了工作。"
        s "今天不说这个话题。"
        b "可惜了。我想把你也争取过来的来着。不过显而易见已经有进展了~ 要是想和我一块找点新鲜事，下次来阿利坎特见我。马德里还是太人多眼杂了。"
        "欲擒故纵吗……也不知道下次在阿利坎特见到他是什么时候。"

        if b_h>0:
            s "你上次，天都没亮就逃走了？丢脸？不想面对？跟我在一起就那么不堪？那你来做什么？"
            "我揪着他的领子质问。"
            b "我怎么知道你是跟人睡了还要个解释的性格。总不能说我要对你负责吧？明天就去塞蒂恩那里把你娶过来？"
            s "理由。我只是想要一个理由。我不是那种随便的人。"
            b "所以后悔的是你。而我现在看着死敌的徒弟在这里纠结。"
            s "所以我们连偷情都不算。"
            b "或者你能找到什么办法发展感情。我不排斥这个~"
            "我，埃德·萨拉维亚，一生要强的毕尔巴鄂男人。我不想问他关于真心的问题，毕竟自知这多多少少有些掉价。会莫名其妙跟着一个阿利坎特男人走，这不是我。"
            "但是，我不相信他是什么刀枪不入的人。如果我想，是否也可以在真心的问题上赢他一局呢。"
        jump chapter1_2ndmatch

label febas_2ndmeet:
    show screen brightness_overlay
    scene bg_elche_scene
    show sarabia:
        xalign 0.5
        yalign 1.0
    "上次之后，我和阿莱克斯表面上的关系一切如常。我们私下的见面很少，更多是训练时的日常对话，结束之后就各做各的事情。"
    "阿莱克斯有一个秘密要告诉我。但我一直没有去见他。一部分是由于赛程，一部分是由于我没想好。但他在球场上看我的，灼热的、躲躲闪闪的眼神，我很难忘记它。"
    "我不知道怎么处理，尤其是无论如何都该保密的时候，尤其是他是你球队的战术核心的时候，尤其是我和他本来就有超越他同胞其他球员的密切交流的时候。"
    "而且，我不知道能不能给出承诺。我被裹挟在西甲的压力、塞蒂恩的需要、博尔达拉斯的诱惑之间。而阿莱克斯，他有他的球要踢。"
    "但无论我的车开得多慢，还是到达了那里。"
    hide sarabia
    show febas:
        xalign 0.8
        yalign 1.0
    f "教练。你从十二点就说要来，我等了你三个小时。如果你没有来，那我就会一直保守着那个秘密。但你还是来了。"
    hide febas
    show sarabia:
        xalign 0.2
        yalign 1.0
    s "抱歉，路上堵车了。"
    hide sarabia
    "阿莱克斯会心一笑，没有拆穿我。平时腼腆的他，仔仔细细地看着我的眼睛。我手心里渗出了薄汗。"
    "他在场上的状态很好，但不像平时的他。有时过度亢奋，有时又过度紧绷。我知道那是紧张，我也在紧张着。"
    show febas:
        xalign 0.8
        yalign 1.0
    f "我觉得我应该道歉。那场比赛，我抢了队友脚下的球，但是没有打进。您说那不是平时的我。"
    f "我知道，我对您已经不一样了。我想在您面前打进那个绝杀球。我想……让您看着我。就算我能不告诉你这个秘密，我也不知道怎么隐藏下去了。"
    hide febas
    "他的眼睛有一种令人着迷的亮，那是属于年轻生命的、还没有被磨平棱角的原石的光辉。我不敢看他，假装是在看窗外，甚至点燃了一根烟。"
    s "……从什么时候开始的？"
    show febas:
        xalign 0.8
        yalign 1.0
    f "我不知道，我想了很久。我是来到埃尔切之后才遇到您的。在西乙没有人踢你这样的战术，也没有人告诉我我还有这样的潜力。在那之后一切都不一样了。我的生活……像梦里一般。"
    f "您对我来说是很特殊的人。但我不是因为这个才随随便便地认定自己的心意的。"
    f "您知道您什么时候会来找我么？球队成绩好的时候，您很少来见我。只有在球队成绩动荡、受不了媒体压力、被塞蒂恩和博尔达拉斯两个男人的理念撕扯的时候，您才来找我。"
    f "我也是一样。只在困难的时候才来找您。我们就这样共享失意的时刻。"
    f "然后我某一天发现，媒体渲染的那个战术大师、塞蒂恩期待的那个接班人、博尔达拉斯想要拉拢的那个死敌弟子，那都不是您，那个经常在更衣室骂人，但是比谁都心思细腻的萨拉维亚教练。他们能让您成为更好的人吗？"
    f "我可以。所以……也请考虑考虑我。"
    hide febas
    "我花了很长时间才转过头去，看到温柔的、涵容一切的笑容和快哭出来的悲伤两种表情同时出现在阿莱克斯的脸上。我心中的防线，几乎是瞬间被击溃。"
    "我不明白，为什么会有人知道了关于我的一切之后，还能够坚定地……说出那种话。"
menu:
    "载他回家，直接本垒":
        $febas_affection+=1
        $ rustness+=1
        "【你感到失去了一部分的自我。请注意，如果失去太多的自我，将会走向不可逆转的毁灭。】" 
        if febas_affection<=3 or rustness<=1:
            f "别这样，萨拉维亚教练。我爱您，我不希望只是用身体满足您。那样太不认真了。"
            jump chapter1_2ndmatch
        else:
            "阿莱克斯不敢相信事情发生的速度，他看着我，忧心地欲言又止了一会，最后还是妥协了。似乎他本来本不想和我变成这样，但我的心处在如此混乱的漩涡之中，急需一个宣泄的出口。"
            "所以我选择了，肉体。"
            $f_h+=1
            jump febas_h1

    "抱住他，但先不做承诺":
        if febas_affection <=3:
            show febas:
                xalign 0.8
                yalign 1.0
            f "教练，我知道你在安慰我，但你的心不在我这里。我能感觉到。今天的事情就当没发生吧。"
            jump chapter1_2ndmatch
        else:
            $ febas_affection +=2
            show febas:
                xalign 0.8
                yalign 1.0
            "我抱住了他。可最后变成了稳稳地抱住我的是他，而颤抖不停的是我。面对这样一个纯粹而坚定的灵魂，我不敢做承诺，也不敢毁掉他。"
            f "教练，我知道您不会在乎那些……职业伦理。您只是还在害怕，举棋不定，怀疑我说的话。我们都好好想想，然后请告诉我答案，我会等您的。"
            hide febas
            show sarabia:
                xalign 0.5
                yalign 1.0
            "阿莱克斯离开之后，我一拳捶在车窗上。为什么不早一点察觉，在足球世界的那些权谋交锋之中，还有一个人怀着这样的心等待着我？"
            jump chapter1_2ndmatch
    "你是球员，我是教练……":
        $ febas_affection -=1
        show febas:
            xalign 0.8
            yalign 1.0
        f "好吧，教练。我知道您的答案了。今天的事情，您就当没发生就好，不能影响工作。"
        "(阿莱克斯的眼神黯淡了。)"
        jump chapter1_2ndmatch
label febas_h1:
    show screen brightness_overlay
    scene bg_alicante_hotel
    "他向我告白了，我也很快回应了。塞蒂恩、博尔达拉斯、该死的媒体、战术板、埃尔切，我都不愿意去想，我只想在这具年轻的、信任和崇拜着我的身体上榨取一点慰藉。"
    "我在车上就有意挑逗他，看着他因为羞涩和期待而变得窘迫，我又笑了起来。授教这一块，作为年长者的我，还是精通的。"
    "一来到酒店我就把他按在门板上亲吻，看着他白皙的胸膛因为窒息而剧烈起伏着。灯光昏暗。平日里腼腆的阿莱克斯，期待又恐惧着，抗拒又邀请着我的触碰。"
    "我甚至急切到不愿意去探索他，就这么看着那个唯一用敬重的眼光看着我的年轻灵魂，沉入和我此时所在之处相同的，粘稠的黑暗之中。"
    scene black
    "那副传出那么多好球、赢得那么多对抗的健美躯体，在床榻上是那么漂亮，又是那样听信于我。"
    "我要了很多次。他仔细地回应着我。然后在黑暗之中，我摸到了他脸上的泪水。"
    f "教练……"
    s "痛的话，告诉我啊？"
    f "{b}你为什么不看我的眼睛？{/b}"
    "我到底为什么，会变成这样。好像在找一个，埃德·萨拉维亚的陪葬品。"
    jump chapter1_2ndmatch
label setien_3rdmeet:
    return
label bordalas_3rdmeet:
    return
label febas_3rdmeet:
    return
label chapter1_ending:
    return

    return
