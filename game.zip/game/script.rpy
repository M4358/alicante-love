
define s = Character("埃德·萨拉维亚", color="#d9d9d9")
define f = Character("阿莱克斯·费巴斯", color="#7CFC00")
define k = Character("基克·塞蒂恩", color="#87CEFA")
define b = Character("何塞·博尔达拉斯", color="#FFA07A")

default setien_affection = 0
default bordalas_affection = 0
default febas_affection = 0
default victories=0
default failures=0
default chuankong=0
default nofangfan=1
default rustness=0
default setien_h=0
default bordalas_h=0
default febas_h=0
default endings_unlocked = []

screen brightness_overlay():

    add Solid("#000") alpha 0.03*rustness

image bg_santander=Transform("images/santander.png",zoom=1.2)
image bg_training=Transform("images/training.png",zoom=1.2)
image bg_getafe=Transform("images/getafecf.png",zoom=1.2)
image bg_elche_scene=Transform("images/elche_scene.png",zoom=1.2)
image bg_elche_night=Transform("images/elche-night.png",zoom=1.2)
image bg_setien_inner=Transform("images/setien_inner.png",zoom=1.3)
image bg_setien_outside=Transform("images/setien_outside.png",zoom=1.3)
image bg_alicante_scene=Transform("images/alicante_scene.png",zoom=1.2)
image bg_alicante_hotel=Transform("images/alicante_hotel.png",zoom=1.3)
image black=Transform("images/black.png",zoom=1.5)
image bordalas = Transform(
    "images/bordalas.png",
    zoom=0.7
)
image setien = Transform(
    "images/setien.png",
    zoom=0.7
)
image febas = Transform(
    "images/febas.png",
    zoom=0.7
)
image sarabia = Transform(
    "images/sarabia.png",
    zoom=0.7,
    size=(1210,1536)
)
label start:

    scene bg_elche_scene

    "《阿利坎特之恋》————序章"

    show sarabia:
        xalign 0.5
        yalign 1.0

    "这是我来到埃尔切，这座阿利坎特海边的古典小城市的第二年。阿利坎特的夏天，晴空万里，空气浓稠而炙热，所有的东西都开始狂热，都开始升腾。"

    "我刚刚带领埃尔切足球俱乐部重返西甲。球员们把我抛起来，高喊着萨拉维亚教练的名字。球迷们夹道欢迎，彻夜欢歌。"

    s "(欢呼) 该死的，我们赢了！我们回西甲了！"

    "但是，阿利坎特的夏天可是很热的。有什么燃烧起来了，我的预感告诉我，这个夏天会发生狂热的、炽烈的、熔化一切的事情。我不知道是好是坏，也不知道接下来的时光里，我会永远得到或失去什么。"
    hide sarabia
    show febas:
        xalign 0.8
        yalign 1.0

    f "（对采访）感谢萨拉维亚教练一年来对我毫无保留的信任，我一直将他当作我的家人一般看待。"
    hide febas
    show setien:
        xalign 0.8
        yalign 1.0
    k  "埃德，我一直都最看好你、最信任你。现在你成功了，你踢出了如此出色的传控，而且取得了如此耀眼的成绩。我为你骄傲。"
    hide setien
    show bordalas:
        xalign 0.8
        yalign 1.0
    b  "没想到你小子居然带队升级了，小萨拉维亚。可西甲的舞台，还是papa我的实用主义足球的天地~"
    hide bordalas

menu:

    "去混采区表扬阿莱克斯一番":
        $ febas_affection += 1
        jump febas_scene1

    "回复博尔达拉斯的挑衅短信":
        $ bordalas_affection += 1
        jump bordalas_scene1
    
    "和恩师共同庆贺升级":
        $ setien_affection += 1
        jump setien_scene1

label setien_scene1:

    scene bg_santander


    
    "那个人的教诲一直指引着我。那个从小呵护着我的人，替我在巴萨挡住媒体的长枪短炮的人，那个从父亲还在桑坦德竞技效力的时候我就追随的人。"
    "球队一升级，我就给老师发了邮件，要知道我足球的理念全部源自于他，我的战术也全部是在跟随他的六年中学来，在后来独立执教的时光里，一次又一次实践。所以，这份荣誉，也是属于他的，我在埃尔切第一年的成功，第一个要分享的，也是他。"
    show sarabia:
        xalign 0.5
        yalign 1.0
    s "塞蒂恩先生！你回西班牙了。"
    hide sarabia
    show setien:
        xalign 0.8
        yalign 1.0
    k "好样的，埃德。你的每场比赛我都看了，细节上有一些瑕疵，但整体做得非常漂亮。传控足球的精髓就在于每个人都像一枚棋子一样精密。"

    k "我买了坎塔布里亚海的鲑鱼和安达卢西亚的赫雷斯酒。今晚是属于你的，好好吃些东西，新赛季继续努力。"
    hide setien
    show sarabia:
        xalign 0.5
        yalign 1.0
    "我和塞蒂恩先生已经共事六年了。在坎塔布里亚，他见证着我成长，在安达卢西亚，我们并肩作战，他设计出精密的战术，我把它们传达给球员。还有巴塞罗那和拉斯帕尔马斯。"
    "那么多年里，他总是一板一眼，从来没有像今天这样笑过，笑得脸上的皱纹都完全舒展开了，即使在他自己生涯的巅峰也没有。他是真心为我的成就而骄傲的。"

    s "塞蒂恩先生，您还是多笑笑嘛。"
    hide sarabia
    show setien:
        xalign 0.8
        yalign 1.0

    k "你执教安道尔踢出来的战术，没把我气死都不错了。现在好多了。你得继续加油，别让我失望啊，埃德。"

    "为了不让塞蒂恩先生失望，我会好好努力的。"

    jump chapter1_1stmatch

label bordalas_scene1:

    scene bg_getafe

    "何塞·博尔达拉斯，我恩师的死敌，那位长相像街痞，被赫塔菲的拥趸们尊为papa的阿利坎特主教练。"
    "他把足球踢成了一场街头斗殴，极度务实，也极度破碎与凌乱，整天就在构思一些研究裁判、犯规和盘外招之类的东西，把恩师和我气的七窍生烟，天天在媒体上指桑骂槐。而且他说话真让人恶心。"

    show sarabia:
        xalign 0.5
        yalign 1.0    

    s "你*个**的踢**足球的玩意，又玩盘外招。你那一套我可没少研究，等我去了西甲，我会把球稳稳当当地传进你的球门。"
    hide sarabia
    show bordalas:
        xalign 0.8
        yalign 1.0

    b "你又不是不知道，你恩师在papa我手下可从没尝到什么甜头。既然你这么有自信，要不要打个赌？"
    hide bordalas
    show sarabia:
        xalign 0.5 
        yalign 1.0
    s "赌就赌，你**不会是觉得我没胆量吧。我会赢你三个。"
    hide sarabia
    show bordalas:
        xalign 0.8
        yalign 1.0

    b "好啊，输了可不许骂裁判。你要是输了，就带着阿利坎特上好的特产来聆听我的伟大教诲吧。"
    hide sarabia
    show bordalas:
        xalign 0.8
        yalign 1.0
    s "（能不能别这么自恋……）"


    jump chapter1_1stmatch

label febas_scene1:

    scene bg_elche_night
    "阿莱克斯·费巴斯，我队伍里最有灵性的球员，也是我最信任的战术核心。他总是能够精确找到对手阵型的空当，一丝不苟地跑出那些复杂的球路，而且训练还十分努力。"
    "而且，他对我和我的传控哲学深信不疑。"
    show febas:
        xalign 0.8
        yalign 1.0

    f "教练，你怎么来了。"
    "阿莱克斯从后面揽住我，我们一起站在采访区。我们之间的关系是不是显得太过于好了？但考虑到他是一个如此严肃认真的球员……"
    hide febas
    show sarabia:
        xalign 0.8
        yalign 1.0

    s "阿莱克斯是这支埃尔切当之无愧的战术核心。我感激能遇到这么好的球员，也感谢他不遗余力、倾尽所有，把自己的全部才华和努力奉献给了这支埃尔切，才会有今天的升级。"
    hide sarabia
    "聚光灯下，阿莱克斯似乎腼腆地笑了。"
    jump chapter1_1stmatch

label chapter1_1stmatch:
    "《阿利坎特之恋》————第一章"
    scene bg_elche_night

    show sarabia:
        xalign 0.5
        yalign 1.0
    "西甲联赛开始了。我期待新的挑战，也感受到压力。埃尔切的总监支持我，为我买来了很多球员，种种期待落在我身上。"
    "我想让阿莱克斯发挥更大的光芒，也想把我在西乙时期贯彻的塞蒂恩主义和细腻传控发扬光大，还得狠狠挫一挫博尔达拉斯这家伙的锐气。"

    "不过作为一个西甲教练，压力也很大……西甲的赛场比西乙更为残酷。接下来一段时间的赛程，踢什么战术呢？"
menu:

    "传控":
        $ setien_affection+=1
        $ chuankong += 1
        $ victories += 1
        jump victory1_1

    "防反":
        $ bordalas_affection += 1
        $ nofangfan =0
        $ chuankong-=1
        $ rustness +=1
        $ failures +=1
        jump defeat1_1
    
    "征求一下阿莱克斯的意见？":
        $ febas_affection += 1
        $ chuankong +=1
        $ victories+=1
        jump aleix_instruction

label aleix_instruction:
    scene bg_elche_night
    show febas:
        xalign 0.8
        yalign 1.0
    f "教，教练？您问我踢得顺不顺利？"
    f "就踢我们原来在西乙踢的那套吧，请信任我，我一定会为您串联起美妙的进攻的。"
    s "（不用问也知道……）"
    jump victory1_1


label victory1_1:
    show bg_elche_night
    "用着从西乙时期就坚持的精细传控战术，我们在这一段时间不仅所向披靡，还能取得很多大胜。笑容洋溢在更衣室每个人的脸上。"
    "那个总是和我一起研究战术到深夜的人……有在看吗？"
    "阿莱克斯完成得非常好。他还有什么我不知道的惊喜才能？"
    jump chapter1_1stmeet

label defeat1_1:
    show screen brightness_overlay
    show bg_elche_night
    "我试图转向务实打法，可是不得要领。我们没有一技之长，毫无抵抗之力地溃败。"
    "阿莱克斯有点失望，这样下去，不是办法。"
    "一到西甲就背叛了塞蒂恩先生的战术，我也变得太怯懦了，我都不敢想他会怎么说我。难道我们共同追求的伊甸园，是那么地无谓？"
    "我是不是被博尔达拉斯那家伙影响太深了？"
    jump chapter1_1stmeet

label chapter1_1stmeet:
    show screen brightness_overlay
    scene bg_elche_scene
    "赛程中间的小小间歇，要去见一见谁吗？"
menu:
    "塞蒂恩先生":
        jump setien_1stmeet
    "何塞·狗尔达拉斯":
        jump bordalas_1stmeet
    "阿莱克斯":
        jump febas_1stmeet

label setien_1stmeet:
    scene bg_setien_outside
    show sarabia:
        xalign 0.2
        yalign 1.0
    "赛程的小小间歇，我来到了塞蒂恩先生在桑坦德的住所，坎塔布里亚海边的小屋。远渡重洋执教不顺，赋闲之后，塞蒂恩先生一直住在这里。"
    "独立执教六年，期间发生了那么多的事情，这里对我来说是港湾一样的地方……或者洋溢着更复杂情绪的地方。"
    "我敲了门。"
    
    if chuankong<0:
        hide sarabia
        show setien:
            xalign 0.8
            yalign 1.0
        k "恕不接待。我倾囊相授，埃德，不是为了有一天拿你踢出来那套丑陋足球打我的脸！"
        "再怎么求情，塞蒂恩先生都不放我进去。"
        jump chapter1_2ndmatch
    if chuankong>0:
        $ setien_affection+=1
        scene bg_setien_inner
        show setien:
            xalign 0.8
            yalign 1.0
        k "埃德，你来了。你是不是又在更衣室发脾气了？眉头的皱纹都多了。你的比赛，我每场都看。"
        s "有、有达到先生的严格要求吗？"
        "不知怎么地，我一和塞蒂恩先生说话就有点结巴。他还是那副不苟言笑的样子。"
        k "比起上赛季有长进吧。埃德，你还是该稳重点，你这样太容易被媒体做文章了。"
        "似乎还是没有得到全然的认可，有点挫败。后半句的说教，我权当耳旁风了，塞蒂恩先生不明白，我做他身边那个张扬的战术推行者，总好过让他承担一切压力。"
        "塞蒂恩先生做了简单的餐食，我们坐在小屋的桌边，吹着坎塔布里亚的海风，仿佛回到了从前。父亲和他在踢球的时候相识，我从8岁就一直仰望着他，后来他提拔我，我跟着他走南闯北。"
        "我注意到电视柜角的劳拉西泮，似乎从出海执教失败以来，塞蒂恩先生的精神状态就有些令人担忧……"
        s "好吃！（挤眉弄眼）"
        k "别一副那么谄媚的样子。"
        hide sarabia
        hide setien

        "晚饭后，我们探讨起战术。塞蒂恩先生坐在我身后，认真地在笔记本上圈圈画画，有时赞赏我的战术设计，有时会强行纠正我。"
        show setien:
            xalign 0.8
            yalign 1.0
        k "埃德，我年纪大了。我所有的东西，都传给你了，我和我们的梦想，也只有你了……"
        "他的手覆在我的手上，似乎除了传道授业之外，意有所指。我不敢相信地对上塞蒂恩先生的眼睛，那双眼睛闪烁着一些……危险的秘氛。"
        hide setien
        menu:
            "顺势倒进塞蒂恩的怀里":
                "这个人似乎前所未有地脆弱，渴求着我的依赖。我又怎么能不回应？"
                $ setien_affection +=1
                $ rustness +=1
                k "埃德……以后多来看看我。"
                s "……好。"
            "握住塞蒂恩的手":
                "塞蒂恩先生……压力太大了。"
                $ setien_affection +=1
                s "您就放一万个心吧，我会好好把学到的东西用在带教上的。"
            "慌不择路地逃离":
                $ setien_affection -=1
                k "(捶桌子）为什么！连埃德也逃走了？"
        jump chapter1_2ndmatch
label bordalas_1stmeet:
    show screen brightness_overlay
    scene bg_alicante_scene
    show sarabia:
        xalign 0.5
        yalign 1.0
    "那个老和我在媒体上打口水仗的轻佻老男人，好像回了老家阿利坎特。他问我要不要喝一杯，我起初没理他。"
    "然后我就在难以言喻的冲动之下驱车一小时，出现在这里了。"
    if chuankong>0:
        hide sarabia
        show bordalas:
            xalign 0.8
            yalign 1.0
        b "抱歉啦，我的日程还是挺忙的呢~塞蒂恩身后那个亦步亦趋的小子啊，何必非要见我不可呢？"
        jump chapter1_2ndmatch
    if chuankong<0:
        hide sarabia
        show sarabia:
            xalign 0.2
            yalign 1.0
        "我不知道为什么开车过来，也不知道为什么最后就在这里了。我坐在博尔达拉斯的对面，用吸管搅着威士忌里的冰块……"
        show bordalas:
            xalign 0.8
            yalign 1.0
        b "我听说你在禁区前面蹲坑防守，让人踢了个3-0。你来我这，总不能是投诚吧？赫塔菲缺个助教，你要不先跟着我学一年？"
        s "停停停，你邀请我，我才来的，又不是谁闲的**非要来你这里。"
        b "那你也知道我为什么邀请你吧？刚出道就背叛师门的小子？我在你这，看到了些许潜力，你会成为大放异彩的战术天才，但首先你要成为你自己。"
        "其实相谈还算是开心，博尔达拉斯是一个轻佻之下意外热心的人，只是我不太愿意承认。塞蒂恩先生总是太端着，跟着他，总觉得自己年纪轻轻就没有了活力。"
        "赌上我毕尔巴鄂人的尊严，我要把他喝翻。酒过三巡之后，我后悔了。"
        "这个62岁的阿利坎特男人怎么这么能喝！"
        hide sarabia
        b "跟着塞蒂恩那么久，你怎么可能懂防守。"
        b "……也怎么可能懂，阿利坎特人的，{b}生活方式{/b}。"
        "迷糊之中，他向我伸出了手。尽管我神智还算是清明，但是那一句话，我怀疑我会错意了。"
        menu:
            "跟着他走":
                $bordalas_affection +=1
                $rustness +=1
                jump bordalas_h1
            "时候不早了，离开吧":
                jump chapter1_2ndmatch
label bordalas_h1:
    show screen brightness_overlay  
    scene bg_alicante_hotel
    
    "我，埃德·萨拉维亚，一位一生要强的毕尔巴鄂男人。我不知道为什么就跟着他走了，就像被塞壬歌声蛊惑的船员一般。"
    "他去隔壁酒店开了个房间，说是得把这个喝的有点神志不清的男人安顿好。我知道我没有神志不清，他也不是为了安顿好我。"
    "在那里，发生了无法言喻的事情。在此之前，我觉得我对塞蒂恩先生和他的战术理念忠心耿耿。但是从决定驱车前来的那一刻，到现在，我并不想踩下刹车。"
    "原谅我……这哪里是一场，像样的反叛。"
    show sarabia:
        xalign 0.8
        yalign 1.0
    s "博尔达拉斯，你哪来的胆子？"
    hide sarabia
    show bordalas:
        xalign 0.8
        yalign 1.0
    b "你哪来的胆子跟着我上车，小萨拉维亚？"
    hide bordalas   
    "“小萨拉维亚”其实应该是对我的官方称呼，因为我的父亲马努·萨拉维亚是他的同辈。但事到如今，这个称呼早就生了什么调情的意味。"
    "我汗湿的肌肤和他紧实有力的胸膛贴在一起。他哪来的胆子吻我？我又是哪来的胆子，磕磕绊绊咒骂着回应？"
    s "难道你是一个，为了招揽死敌的徒弟，连肉体关系都来者不拒的人？"
    b "你自己的脚让你走了上来。你自己的欲望让你沉迷于此，小萨拉维亚。你得正视它们，你该学会享受。我打赌，塞蒂恩这个老顽固一辈子没享受过这些。"
    "对他而言，这只是阿利坎特的一场普通迷情？我的脑子已经被搅得乱七八糟了。但不得不承认，他在这里的技巧，比他的球员在场上犯规的技巧还要丰富……"
    scene black
    "……"
    scene bg_alicante_scene
    "天亮了。"
    "博尔达拉斯，消失了。"
    "我从未觉得如此失控过。"
    jump chapter1_2ndmatch
label febas_1stmeet:
    scene bg_elche_scene
    "去见他吧。敏感的阿莱克斯最近训练格外刻苦，我想让他知道他的努力有被看见。尽管在我驱车去他家的路上，隐秘的不安感席卷着我。我很了解他，最近他的眼睛看向我的次数变多了。"
    "他的职业生涯很不顺利，明明有着不俗的水平，却大器晚成，随队回到西甲时已经30岁了。从马拉加降级之后，他就一直蹉跎西乙，我们不可谓不是彼此命运中的转折人物，因此关系很特殊。"
    "但是……他需要一些正确的引导，我本不该频繁和他接触。这样下去，我是否，也在纵容他？或是……纵容自己？塞蒂恩先生说过，过度的纵容会毁了我。"
    show febas:
        xalign 0.8
        yalign 1.0
    f "教练，家访之前说一声嘛。"
    show sarabia:
        xalign 0.2
        yalign 1.0
    "他坐进了我的副驾。看到我过来，平时腼腆的他笑得格外开心。"
    f "我最近有在加练。虽然大家都习惯了被您在更衣室训，但最近您好像训得更多了，所以我也在想，是不是自己有点太过松懈了什么的。"
    s "加练？你还是太把我的态度当回事了，我就那性格。我就是担心你会错了意，然后逼自己太紧，所以来特意点拨你。实际上，这几场，你……踢得太好了，超出我能想到的好。"
    f "呵呵呵……恐怕您是因为从来没在塞蒂恩先生那里听到这句话，才迫不及待地对我说的吧？请别这样，我会高兴过头的。"
    s "哪有。总之，自信些不是坏事。"
    "塞蒂恩先生。跟他说话时，我嘴里总是会不知为何吐出一些对塞蒂恩先生的抱怨。我仰望和追随着塞蒂恩先生；然后现在有一个年轻干净的灵魂，开始隐隐约约以同样的方式仰望和追随着我。"
    "真正站在这个角色上的时候很沉重。但是这也让我想成为更好的人。"
    f "教练，这么久了……我有一个秘密要告诉你。"
    f "……还是算了。下次见面的时候再说吧。"
    "他的眼神，出卖了一切。"
menu:
    "以年长者的经验，直接吻他":
        $ febas_affection +=1
        $ rustness +=1
        "按说作为年长者应该更加主动；我在这些情感还是混沌的时候听信了自己的本能，把他拉进怀里，然后吻到他嘴唇红肿才放开。"
        "阿莱克斯不敢置信，脸颊红扑扑的，却也不肯和我分开。而本该引导的我，直接拉着他的手，往自毁的禁忌深渊里跳。"
        jump chapter1_2ndmatch
    "秘密需要时间沉淀，那就下次再说":
        $ febas_affection +=1
        f "谢谢你。"
        f "我会……深思熟虑的。"
        jump chapter1_2ndmatch
    "别再走上歧途了，作为年长者敲打他":
        $febas_affecion -=1
        s "如果是我想的那样的话，就先别说吧，别再给自己暗示。好好想想你的未来，你后面的职业生涯，如果误入歧途我们只会彼此耽误。"
        f "您退缩了么……可我不是缺乏理性的人。"
        jump chapter1_2ndmatch
label chapter1_2ndmatch:
    return
