
define s = Character("埃德·萨拉维亚", color="#d9d9d9")
define f = Character("阿莱克斯·费巴斯", color="#7CFC00")
define k = Character("基克·塞蒂恩", color="#87CEFA")
define b = Character("何塞·博尔达拉斯", color="#FFA07A")

default setien_affection = 0
default bordalas_affection = 0
default febas_affection = 0
default victories=0
default failures=0
default chuankong=0
default nofangfan=1

image bg_santander=Transform("images/santander.png",zoom=1.2)
image bg_training=Transform("images/training.png",zoom=1.2)
image bg_getafe=Transform("images/getafecf.png",zoom=1.2)
image bg_elche_scene=Transform("images/elche_scene.png",zoom=1.2)
image bg_elche_night=Transform("images/elche-night.png",zoom=1.2)
image bordalas = Transform(
    "images/bordalas.png",
    zoom=0.7
)
image setien = Transform(
    "images/setien.png",
    zoom=0.7
)
image febas = Transform(
    "images/febas.png",
    zoom=0.7
)
image sarabia = Transform(
    "images/sarabia.png",
    zoom=0.7,
    size=(1210,1536)
)
label start:

    scene bg_elche_scene

    "《阿利坎特之恋》————序章"

    show sarabia:
        xalign 0.5
        yalign 1.0

    "这是我来到埃尔切，这座阿利坎特海边的古典小城市的第二年。阿利坎特的夏天，晴空万里，空气浓稠而炙热，所有的东西都开始狂热，都开始升腾。"

    "我刚刚带领埃尔切足球俱乐部重返西甲。球员们把我抛起来，高喊着萨拉维亚教练的名字。球迷们夹道欢迎，彻夜欢歌。"

    s "(欢呼) 该死的，我们赢了！我们回西甲了！"

    "但是，阿利坎特的夏天可是很热的。有什么燃烧起来了，我的预感告诉我，这个夏天会发生狂热的、炽烈的、熔化一切的事情。我不知道是好是坏，也不知道接下来的时光里，我会永远得到或失去什么。"
    hide sarabia
    show febas:
        xalign 0.8
        yalign 1.0

    f "（对采访）感谢萨拉维亚教练一年来对我毫无保留的信任，我一直将他当作我的家人一般看待。"
    hide febas
    show setien:
        xalign 0.8
        yalign 1.0
    k  "埃德，我一直都最看好你、最信任你。现在你成功了，你踢出了如此出色的传控，而且取得了如此耀眼的成绩。我为你骄傲。"
    hide setien
    show bordalas:
        xalign 0.8
        yalign 1.0
    b  "没想到你小子居然带队升级了，小萨拉维亚。可西甲的舞台，还是papa我的实用主义足球的天地~"
    hide bordalas

menu:

    "去混采区表扬阿莱克斯一番":
        $ febas_affection += 1
        jump febas_scene1

    "回复博尔达拉斯的挑衅短信":
        $ bordalas_affection += 1
        jump bordalas_scene1
    
    "和恩师共同庆贺升级":
        $ setien_affection += 1
        jump setien_scene1

label setien_scene1:

    scene bg_santander


    
    "那个人的教诲一直指引着我。那个从小呵护着我的人，替我在巴萨挡住媒体的长枪短炮的人，那个从父亲还在桑坦德竞技效力的时候我就追随的人。"
    "球队一升级，我就给老师发了邮件，要知道我足球的理念全部源自于他，我的战术也全部是在跟随他的六年中学来，在后来独立执教的时光里，一次又一次实践。所以，这份荣誉，也是属于他的，我在埃尔切第一年的成功，第一个要分享的，也是他。"
    show sarabia:
        xalign 0.5
        yalign 1.0
    s "塞蒂恩先生！你回西班牙了。"
    hide sarabia
    show setien:
        xalign 0.8
        yalign 1.0
    k "好样的，埃德。你的每场比赛我都看了，细节上有一些瑕疵，但整体做得非常漂亮。传控足球的精髓就在于每个人都像一枚棋子一样精密。"

    k "我买了坎塔布里亚海的鲑鱼和安达卢西亚的赫雷斯酒。今晚是属于你的，好好吃些东西，新赛季继续努力。"
    hide setien
    show sarabia:
        xalign 0.5
        yalign 1.0
    "我和塞蒂恩先生已经共事六年了。在坎塔布里亚，他见证着我成长，在安达卢西亚，我们并肩作战，他设计出精密的战术，我把它们传达给球员。还有巴塞罗那和拉斯帕尔马斯。"
    "那么多年里，他总是一板一眼，从来没有像今天这样笑过，笑得脸上的皱纹都完全舒展开了，即使在他自己生涯的巅峰也没有。他是真心为我的成就而骄傲的。"

    s "塞蒂恩先生，您还是多笑笑嘛。"
    hide sarabia
    show setien:
        xalign 0.8
        yalign 1.0

    k "你执教安道尔踢出来的战术，没把我气死都不错了。现在好多了。你得继续加油，别让我失望啊，埃德。"

    "为了不让塞蒂恩先生失望，我会好好努力的。"

    "【塞蒂恩好感度上升】"

    jump chapter1

label bordalas_scene1:

    scene bg_getafe

    "何塞·博尔达拉斯，我恩师的死敌，那位长相像街痞，被赫塔菲的拥趸们尊为papa的阿利坎特主教练。"
    "他把足球踢成了一场街头斗殴，极度务实，也极度破碎与凌乱，整天就在构思一些研究裁判、犯规和盘外招之类的东西，把恩师和我气的七窍生烟，天天在媒体上指桑骂槐。而且他说话真让人恶心。"

    show sarabia:
        xalign 0.5
        yalign 1.0    

    s "你*个**的踢**足球的玩意，又玩盘外招。你那一套我可没少研究，等我去了西甲，我会把球稳稳当当地传进你的球门。"
    hide sarabia
    show bordalas:
        xalign 0.8
        yalign 1.0

    b "你又不是不知道，你恩师在papa我手下可从没尝到什么甜头。既然你这么有自信，要不要打个赌？"
    hide bordalas
    show sarabia:
        xalign 0.5 
        yalign 1.0
    s "赌就赌，你**不会是觉得我没胆量吧。我会赢你三个。"
    hide sarabia
    show bordalas:
        xalign 0.8
        yalign 1.0

    b "好啊，输了可不许骂裁判。你要是输了，就带着阿利坎特上好的特产来聆听我的伟大教诲吧。"
    hide sarabia
    show bordalas:
        xalign 0.8
        yalign 1.0
    s "（能不能别这么自恋……）"

    "【博尔达拉斯好感度上升】"

    jump chapter1

label febas_scene1:

    scene bg_elche_night
    "阿莱克斯·费巴斯，我队伍里最有灵性的球员，也是我最信任的战术核心。他总是能够精确找到对手阵型的空当，一丝不苟地跑出那些复杂的球路，而且训练还十分努力。"
    "而且，他对我和我的传控哲学深信不疑。"
    show febas:
        xalign 0.8
        yalign 1.0

    f "教练，你怎么来了。"
    "阿莱克斯从后面揽住我，我们一起站在采访区。我们之间的关系是不是显得太过于好了？但考虑到他是一个如此严肃认真的球员……"
    hide febas
    show sarabia:
        xalign 0.8
        yalign 1.0

    s "阿莱克斯是这支埃尔切当之无愧的战术核心。我感激能遇到这么好的球员，也感谢他不遗余力、倾尽所有，把自己的全部才华和努力奉献给了这支埃尔切，才会有今天的升级。"
    hide sarabia
    "聚光灯下，阿莱克斯似乎腼腆地笑了。"
    "【费巴斯好感度上升】"
    jump chapter1

label chapter1:
    "《阿利坎特之恋》————第一章"
    scene black

    "西甲联赛开始了。我期待新的挑战，也感受到压力。埃尔切的总监支持我，为我买来了很多球员，种种期待落在我身上。"
    "我想让阿莱克斯发挥更大的光芒，也想把我在西乙时期贯彻的塞蒂恩主义和细腻传控发扬光大，还得狠狠挫一挫博尔达拉斯这家伙的锐气。"

    if setien_affection >= 1:
        "你与塞蒂恩之间，似乎还有未完成的故事。"

    if bordalas_affection >= 1:
        "博尔达拉斯向你发来了一条奇怪的信息。"

    if febas_affection >= 1:
        "费巴斯看向你的目光，似乎变得不同了。"

    "感谢游玩《阿利坎特之恋》 DEMO！"

    return
